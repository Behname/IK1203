import java.net.*;
import java.io.*;

public class HTTPAsk {

    public static void main(String[] args) throws IOException{
        try {
            int port = Integer.parseInt(args[0]);
            ServerSocket ssocket = new ServerSocket(port);

            while (true) {
                StringBuilder ModifiedString = new StringBuilder();
                Socket csocket = ssocket.accept();
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(csocket.getInputStream()));
                DataOutputStream outToServer = new DataOutputStream(csocket.getOutputStream());
                String ServerString = inFromClient.readLine();
                csocket.setSoTimeout(5000);


                while (ServerString != null && ServerString.length() != 0) {
                    ModifiedString.append(ServerString + "\n");
                    ServerString = inFromClient.readLine();
                }

                // String[] SArray = ModifiedString.toString().split("hostname=");
                //System.out.println(SArray[0]);
                //System.out.println(ModifiedString.toString());
                //ModifiedString.toString.split();
                // Split();

                String[] Asplit = ModifiedString.toString().split("=");
                String[] Bsplit = ModifiedString.toString().split("port=");
                String[] A2split = Asplit[1].split("&");
                String[] B2split = Bsplit[1].split(" HTTP/1.1"); //wait what fixa vi inte detta förra gången? joo

                try {
                    int portnr = Integer.parseInt(B2split[0]);
                    String TCPC = askServer(A2split[0], portnr);
                    String echo = "HTTP/1.1 200 OK" + "\r\n"
                            + "Content-type: text/plain" + "\r\n"
                            + "Content-length" + TCPC.length() + "\r\n\r\n";

                    outToServer.writeBytes(echo + TCPC + "\n");

                    csocket.close();

                } catch(java.lang.NumberFormatException e){
                }
            }
        }catch(java.io.IOException e) {
            System.out.println("Error IOException");
        }

    }

    public static String askServer(String hostname, int port, String ToServer) throws IOException {

        if (ToServer == null)
            return askServer(hostname, port);
        else {

            Socket S = new Socket(hostname, port);
            S.setSoTimeout(11050);
            BufferedReader InB = new BufferedReader(new InputStreamReader(S.getInputStream()));
            DataOutputStream outToServer = new DataOutputStream(S.getOutputStream());
            outToServer.writeBytes(ToServer + '\n');
            String modifiedToServer = InB.readLine();
            StringBuilder modified = new StringBuilder();

            try {


                while (modifiedToServer != null) {
                    modified.append(modifiedToServer);
                    modifiedToServer = InB.readLine();
                }


            } catch (java.net.SocketTimeoutException e) {
                return modified.toString();
            }
            S.close();
            return modified.toString();
        }
    }

    public static String askServer(String hostname, int port) throws IOException {
        Socket S = new Socket(hostname, port);
        S.setSoTimeout(250);
        BufferedReader InB = new BufferedReader(new InputStreamReader(S.getInputStream()));
        String line = InB.readLine();
        StringBuilder modified = new StringBuilder();

        try {
            while (line != null) {
                if (modified.length() > 19799)
                    break;
                else {
                    modified.append(line);
                    line = InB.readLine();
                }
            }
        } catch (java.net.SocketTimeoutException e) {
            return modified.toString();
        }

        S.close();
        return modified.toString();
    }

}

